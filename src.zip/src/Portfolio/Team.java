package Portfolio;

public class Team {
    String name;
    Integer wins;
    Integer draws;
    Integer losses;
    Integer points;

    /**
     * This constructor initialises the fields of the class*/
    public Team(String name, Integer wins, Integer draws, Integer losses, Integer points) {
        this.name = name;
        this.wins = wins;
        this.draws = draws;
        this.losses = losses;
        this.points = points;
    }

}